These scripts are used for the "Deploy to AWS with Ansible and Terraform" course on Linux Academy. 
